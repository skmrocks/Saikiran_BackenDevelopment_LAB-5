package com.greatlearning.employee_management_system.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.greatlearning.employee_management_system.entity.Employee;
import com.greatlearning.employee_management_system.service.EmployeeService;

@Controller
public class EmployeeController<EmployeeServicee> {

	private EmployeeService employeeService;

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}

//handler methodto handle list employees amd return mode view
	
	@GetMapping("/employees")
	public String listemployees(Model model) {
		model.addAttribute("employee", employeeService.getALLEmployees());
		return "employees";
	}

	@GetMapping("/employees/new")
	public String createemployeeForm(Model model) {

		// create employee object to hold employee form data
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "create_employee";

	}
	@PostMapping("/employees")
	public String saveEmployee(@ModelAttribute("employee") Employee employee) {
		employeeService.saveEmployee(employee);
		return "redirect:/employee";
	}
	
	@GetMapping("/employee/edit/{id}")
	public void editemployeeForm(@PathVariable Long id, Model model) {
		model.addAttribute("employee", employeeService.getEmployeeById(id));
	}
	

	@PostMapping("/employees/{id}")
	public String updateemployee(@PathVariable Long id, @ModelAttribute("employee") Employee employee, Model model) {
        //get employee form database by id
		Employee existtingEmployee = EmployeeService.getEmployeeById(id);
		existtingEmployee.setId(id);
		existtingEmployee.setFirstName(employee.getFirstName());
		existtingEmployee.setLastName(employee.getLastName());
		employee.getEmail(employee.getEmail());

        //save  updat employee object
		employeeService.updateEmployee(existtingEmployee);
		return "redirect:/employees";existtingEmployee

	}
//handler method to handle delete employee requst

	public String deleteemployee(@PathVariable Long id) {

	}

}