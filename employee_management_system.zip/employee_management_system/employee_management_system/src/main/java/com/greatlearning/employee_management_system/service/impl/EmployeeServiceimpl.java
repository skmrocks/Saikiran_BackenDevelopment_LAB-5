package com.greatlearning.employee_management_system.service.impl;

import java.util.List;

import com.greatlearning.employee_management_system.entity.Employee;
import com.greatlearning.employee_management_system.repository.EmployeeRepository;
import com.greatlearning.employee_management_system.service.EmployeeService;

public class EmployeeServiceimpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	
	public  void EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}

	@Override
	public List<Employee> getAllEmplListEmployees() {
		return employeeRepository.findAll();
	}
    
	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	@Override
	public Employee getEmployeeByid(Long id) {
		return employeeRepository.findById(id).get();
		
	}
	@Override
	public Employee updateEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public void deleteEmployeeById(Long id) {
		employeeRepository.deletebyId(id);
	}

	public List<Employee> getALLEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee getEmployeeById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteEmployeeById1(Long id) {
		// TODO Auto-generated method stub
		
	}

}
