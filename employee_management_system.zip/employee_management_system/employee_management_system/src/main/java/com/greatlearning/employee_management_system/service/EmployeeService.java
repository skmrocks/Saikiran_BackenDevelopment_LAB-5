package com.greatlearning.employee_management_system.service;

import java.util.List;

import com.greatlearning.employee_management_system.entity.Employee;

public interface EmployeeService {
	List<Employee> getALLEmployees();
	
	Employee saveEmployee(Employee employee);
	
	Employee getEmployeeById(Long id);
	
	Employee updateEmployee(Employee employee);
	
	void deleteEmployeeById(Long id);


}
