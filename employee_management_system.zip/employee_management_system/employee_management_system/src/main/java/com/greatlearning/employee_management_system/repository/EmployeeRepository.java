package com.greatlearning.employee_management_system.repository;

public interface EmployeeRepository {

}
